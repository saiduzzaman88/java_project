package product_pkg;

public class Shopping_cart {
   public String name;
   public String brand;
   public double unitPrice;
   public int quantity;
   
   public Shopping_cart(String name,String brand,double unitPrice,int quantity){
	  this.name=name;
	  this.brand=brand;
	  this.unitPrice=unitPrice;
	  this.quantity=quantity;
	   //database theke table anbe
	  
	  
	   
   }
	
}
