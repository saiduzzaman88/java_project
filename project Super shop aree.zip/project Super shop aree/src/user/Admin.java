package user;

public class Admin {

}
