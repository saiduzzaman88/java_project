package main;
import gui_pkg.HomePage;
import gui_pkg.SearchByBrand;
import product_pkg.Mobile_ctgr;
import java.util.*;

/*import com.gui.CountryViewer;
import db.DBConnectionProvider;
import db.DBDataProvider;
import model.Country;

/**
 *
 * @author Student
 */
public class Main {
	Mobile_ctgr mc;
    public static void main(String arg[]){    	
    	//SearchByBrand hp =new SearchByBrand();
    	
       Mobile_ctgr  m_c=new  Mobile_ctgr();
 	  /* Mobile_ctgr  m_c1=new  Mobile_ctgr("0-01","Xiaomi 473",5.5,3.0,13.0,2.2,"Android","Xiaomi",20000,15);
 	   Mobile_ctgr  m_c2=new  Mobile_ctgr("0-01","Xiaomi 473",5.5,3.0,13.0,2.2,"Android","Xiaomi",20000,5);
 	   Mobile_ctgr  m_c3=new  Mobile_ctgr("0-02","Xiaomi N73",5.0,3.5,15.0,5.0,"Android","Xiaomi",22000,13);
 	   Mobile_ctgr  m_c4=new  Mobile_ctgr("0-03","Samsung J2",5.3,2.0,10.0,7.0,"Android","Samsung",15000,9);
 	   Mobile_ctgr  m_c5=new  Mobile_ctgr("0-04","Nokia Lumia Xl",4.5,Double.NaN,5.0,Double.NaN,"Windowsos","Microsoft",21000,17);
 			   
 	   m_c.addMobile(m_c1);
 	   m_c.addMobile(m_c2);
 	   m_c.addMobile(m_c3);
 	   m_c.addMobile(m_c4);
 	   m_c.addMobile(m_c5);*/
 	  HomePage hp=new HomePage();
 	   
 	  
 	   
    }
    
}